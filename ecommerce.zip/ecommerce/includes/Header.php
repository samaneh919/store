<?php
include('functions/function.php');
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>فروشگاه </title>
    <meta name="keywords" content="free website template, flower shop, website templates, CSS, HTML" />
    <meta name="description" content="Flower Shop - free website template, W3C compliant HTML CSS layout" />
    <link href="style.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--  Free CSS Template | Designed by TemplateMo.com  -->
</head>

<body>
    <div id="templatemo_container">
        <div id="templatemo_top_panel">

            <div id="templatemo_shopping_cart">
                <?php
                if (isset($_GET['add_cart'])) {
                    cart();
                    echo " محصول مورد نظر شما به سبد خرید اضافه شد.";
                }
                echo "<span> <b> تعداد محصولات خریداری شده نوسط شما تاکنون </b></span";
                total_items();
                ?>
            </div>

        </div>

        <div id="templatemo_header">
            <a href="index.php" style="cursor:pointer;"><img src="images/logo.gif" height="85px" alt="Flower Shop" /></a>
        </div>

        <div id="templatemo_banner">
            <a href="#"><img src="images/templatemo_banner_image.jpg" alt="Flower Shop - Free Web Template" title="Flower Shop - Free Web Template" border="0" /></a>
        </div>

        <!---start of menu -->
        <div id="templatemo_menu_panel">
            <ul>
                <li><a href="index.php" class="current">خانه</a></li>
                <li><a href="all_products.php" target="_parent">همه محصولات</a></li>
                <li><a href="customer/my_account.php" target="_parent">حساب من</a></li>
                <li><a href="#" target="_parent">SingUp(خروج)</a></li>
                <li><a href="cart.php">سبد خرید</a></li>
                <li><a href='#'>درباره ی ما</a></li>
                <li><a href="#">تماس با ما</a></li>
            </ul>
        </div>
        <!-- end of menu -->