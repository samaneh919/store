<div id="templatemo_footer_panel">
            <div id="footer_left">
                <!-- <img src="images/mastercard.gif" alt="Master Card" /><img src="images/visa.gif" alt="Visa Card" /><img src="images/paypal.gif" alt="PayPal" /><img src="images/verisignsecured.gif" alt="Verisign Secured" /> -->
            </div>
            <div id="footer_right">
                 <a href="#"><h2>فروشگاه ما</h2><br />
                <a href="http://www.iwebsitetemplate.com" target="_parent">Website Templates</a> by
                <a href="http://www.templatemo.com" target="_blank">Free CSS Templates</a>
            </div>

            <div class="cleaner">&nbsp;</div>
        </div>
    </div>
    <!--  Free CSS Template | Designed by TemplateMo.com  -->
    <div class="fot" >حق این سایت برای فروشگاه ما محفوظ است </div>
</body>

</html>