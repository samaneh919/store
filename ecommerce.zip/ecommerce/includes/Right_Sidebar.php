<!---- Start Online Shopping Cart ----> 
<?php	include('includes/Shopping_Cart.php');
        // include('includes/Header.php');
	?>
<!---- end Online Shopping Cart ---->

<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
<div id="templatemo_content_right">
    <div class="templatemo_right_section">
        <h4>جستجو</h4>
        <div class="templatemo_right_section_content">
            <form method="get" action="result.php">
                <input name="user_query" type="text" id="keyword" placeholder="کلمه مورد نظر را اینجا وارد کنید" />
                <input type="submit" name="search" class="button" value="جستجو" />
            </form>
        </div>
    </div>
    <div class="templatemo_right_section">
        <h4>دسته بندی ها</h4>
        <div class="templatemo_right_section_content">
            <ul>
                <?php getCat() ?>
            </ul>
        </div>
    </div>
    <div class="templatemo_right_section">
        <h4>برندها</h4>
        <div class="templatemo_right_section_content">
            <ul>
                <?php getBrand() ?>
            </ul>
        </div>
    </div>
    <div class="templatemo_right_section">
        <h4>  شبکه های اجتماعی</h4>
      
    <div >
        <ul class="socialMedia">
            <a href="#" class="fa fa-instagram"></a>
            <a href="#" class="fa fa-whatsapp"></a>
            <a href="#" class="fa fa-telegram"></a>
            <a href="#" class="fa fa-envelope"></a>
           
        </ul>
    </div>  
    
        </div   > <!-- end of content right-->