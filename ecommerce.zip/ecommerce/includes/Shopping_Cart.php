<div id="sidebar"> 
			<h4>سبد خرید شما</h4>
			<span class="sabad"> سلام کاربر گرامی ، به سایت ما خوش آمدید.</span><br/>
			<span class="sabad">اجناس خریداری شده شما : <?php total_items(); ?> محصول </span><br/>
			<span class="sabad">قیمت کل اجناس خریداری شده :  <?php total_price(); ?></span><br/>
			<span><a>به صندوق خرید شما برویم!</a></span><br/>
			<span><a href="cart.php" >تایید خرید !</a></span>
		</div>